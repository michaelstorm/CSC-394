
document.write('<div id=\"lcontop\">');
document.write('<ul class=\"lmen1\">');
document.write('<li class=\"p10\"><a href=\"index.html\" target=\"_top\">Home</a></li>');
document.write('<li class=\"p20\"><a href=\"start_quick_start.html\"  target=\"_top\">Quick Start</a></li>');
document.write('<li class=\"p300\"><a href=\"general_intro.html\"  target=\"_top\">General</a></li>');
document.write('<li class=\"p400\"><a href=\"apache_intro.html\"  target=\"_top\">Apache</a></li>');


document.write('<li class=\"p500\"><a href=\"mysql_intro.html\"  target=\"_top\">MySQL</a></li>');
document.write('<li class=\"p600\"><a href=\"php_intro.html\"  target=\"_top\">PHP</a></li>');
document.write('<li class=\"p700\"><a href=\"msmtp_intro.html\"  target=\"_top\">MSMTP</a></li>');
document.write('<li class=\"p800\"><a href=\"cron_intro.html\"  target=\"_top\">Cron</a></li>');
document.write('<li class=\"p900\"><a href=\"dtdns_intro.html\"  target=\"_top\">DtDNS</a></li>');


document.write('<li class=\"p1000\"><a href=\"dbbackup_intro.html\"  target=\"_top\">DB Back-up</a></li>');
document.write('<li class=\"p1100\"><a href=\"perl_intro.html\"  target=\"_top\">Perl</a></li>');
document.write('<li class=\"p90\"><a href=\"index_main.html\"  target=\"_top\">Main Index</a></li>');

document.write('</ul>');
document.write('</div>');
