document.write('<table id=\"banner\"><tr><td id=\"td_banner\">');
document.write('<div align=\"center\">');
document.write('<img src=\"common/images/us_coral_logo.gif\" alt=\"The Uniform Server\" />');
document.write('</div>');
document.write('</td></tr></table>');
