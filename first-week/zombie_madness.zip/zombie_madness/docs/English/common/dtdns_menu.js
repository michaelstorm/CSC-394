
document.write('<span class=\"sub_menu_header\">DtDNS</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p910\"><a href=\"dtdns_detail.html\"  target=\"_top\">DtDNS Detail</a></li>');
document.write('<li class=\"p920\"><a href=\"dtdns_account.html\"  target=\"_top\">Create DtDNS Account</a></li>');

document.write('</ul>');
document.write('</div>');
