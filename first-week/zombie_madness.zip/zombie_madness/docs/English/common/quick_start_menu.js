document.write('<span class=\"sub_menu_header\">Quick Start</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p25\"><a href=\"start_quick_start_detail.html\"  target=\"_top\">Quick Start - More Detail</a></li>');
document.write('<li class=\"p27\"><a href=\"start_user_configuration.html\"  target=\"_top\">User Configuration</a></li>');
document.write('<li class=\"p30\"><a href=\"start_run_as_program.html\"  target=\"_top\">Run as a program</a></li>');
document.write('<li class=\"p40\"><a href=\"start_run_as_service.html\"  target=\"_top\">Run as a service</a></li>');
document.write('<li class=\"p45\"><a href=\"start_server_utilities.html\"  target=\"_top\">Server Utilities</a></li>');
document.write('<li class=\"p50\"><a href=\"start_multi_servers.html\"  target=\"_top\">Multi Servers</a></li>');

document.write('</ul>');
document.write('</div>');
