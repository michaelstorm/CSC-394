document.write('<span class=\"sub_menu_header\">General</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p310\"><a href=\"general_change_ports.html\"  target=\"_top\">Change Ports</a></li>');
document.write('<li class=\"p320\"><a href=\"general_clear_logs.html\"  target=\"_top\">Clear Logs</a></li>');
document.write('<li class=\"p330\"><a href=\"general_access_www.html\"  target=\"_top\">Root folder www Access</a></li>');
document.write('<li class=\"p340\"><a href=\"general_access_ssl.html\"  target=\"_top\">Root folder ssl Access</a></li>');
document.write('<li class=\"p350\"><a href=\"general_access_phpmyadmin.html\"  target=\"_top\">Root phpMyAdmin Access</a></li>');

document.write('</ul>');
document.write('</div>');
